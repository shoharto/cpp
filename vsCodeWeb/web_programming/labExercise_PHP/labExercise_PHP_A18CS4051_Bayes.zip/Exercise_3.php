<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="author" content="Bayes Ahmed Shoharto">
    <title>PHP Exercise-03</title>
</head>

<body>

<?php

 
$x=10;

$y=7;

$result=$x+$y;

echo "$x + $y = $result<br />";

$result=$x-$y;

echo "$x - $y = $result<br />";

$result=$x*$y;

echo "$x * $y = $result<br />";

$result=$x/$y;

echo "$x / $y = $result<br />";

$result=$x%$y;

echo "$x % $y = $result<br />";

?> 

</body>

</html>