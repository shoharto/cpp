<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="author" content="Bayes Ahmed Shoharto">
    <title>PHP Exercise-09</title>
</head>

<body>

<?php


for ($x=1; $x<=12; $x++) {
    $result = $x * $x;

    echo "$x * $x = $result <br />\n";
}


?>

</body>
</html>