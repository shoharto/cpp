<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="author" content="Bayes Ahmed Shoharto">
    <title>PHP Exercise-05</title>
</head>

<body>

<?php

$name='Harry';

$age=28;


var_dump($name);

echo "<br/>";


print_r($name);

echo "<br/>";


var_dump($age);

echo "<br/>";

$name=null;

var_dump($name);

?> 

</body>

</html>