<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="author" content="Bayes Ahmed Shoharto">
    <title>PHP Exercise-02</title>
</head>

<body>

<?php

echo "Twinkle, Twinkle little star. <br/>";

$twinkle="Twinkle";

$star="star";

echo "$twinkle, $twinkle little $star.<br/>";

$twinkle="Love";

$star="Brother";

echo "$twinkle, $twinkle little $star.";

?>   

</body>

</html>