<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="author" content="Bayes Ahmed Shoharto">
    <title>PHP Exercise-07</title>
</head>

<body>

<?php

 

$whatsit = 'Shoharto';

echo "Value is ".gettype($whatsit).".<br/>\n";

 

$whatsit = 28.9;

echo "Value is ".gettype($whatsit).".<br/>\n";

 

$whatsit = true;

echo "Value is ".gettype($whatsit).".<br/>\n";

 

$whatsit = 5;

echo "Value is ".gettype($whatsit).".<br/>\n";

 

$whatsit = null;

echo "Value is ".gettype($whatsit).".<br/>\n";

 

?>   

</body>

</html>