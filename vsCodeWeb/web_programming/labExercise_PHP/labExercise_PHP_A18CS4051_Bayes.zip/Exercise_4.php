<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="author" content="Bayes Ahmed Shoharto">
    <title>PHP Exercise-04</title>
</head>

<body>

<?php

$num = 8;

echo "Value is now $num.<br/>";

$num += 2;

echo "Add 2. Value is now $num. <br/>";

$num -= 4;

echo "Subtract 4. Value is now $num. <br/>";

$num *= 5;

echo "Multiply by 5. Value is now $num. <br/>";

$num /= 3;

echo "Divide by 3. Value is now $num. <br/>";

$num++;

echo "Increment value by one. Value is now $num.<br/>";

$num--;

echo "Decrement value by one. Value is now $num.";

?> 

</body>

</html>