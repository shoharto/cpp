<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="author" content="Bayes Ahmed Shoharto">
    <title>PHP Exercise-10 Simple Response</title>
</head>

<body>

<h2>Favorite City</h2>

 
<?php

$city = $_POST['city'];

echo "Your favorite city is $city.";

?>

</body>
</html>